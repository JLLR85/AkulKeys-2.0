import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'dart:async';
import 'dart:math';

void main() => runApp(const AkulKeysApp());

class AkulKeysApp extends StatelessWidget {
  const AkulKeysApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark().copyWith(
        scaffoldBackgroundColor: const Color(0xFF000000), // Negro absoluto
      ),
      home: const AkulTerminal(),
    );
  }
}

class AkulTerminal extends StatefulWidget {
  const AkulTerminal({super.key});
  @override
  State<AkulTerminal> createState() => _AkulTerminalState();
}

class _AkulTerminalState extends State<AkulTerminal> with SingleTickerProviderStateMixin {
  bool isApexMode = false;
  bool isAuthenticated = false;
  late AnimationController _scanController;
  final TextEditingController _originController = TextEditingController();
  final List<Map<String, String>> _vault = [];
  String _systemMessage = "STATUS: SYSTEM_READY";
  double _entropyLevel = 0.0;

  @override
  void initState() {
    super.initState();
    _scanController = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 2),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _scanController.dispose();
    _originController.dispose();
    super.dispose();
  }

  void _generateKey() {
    String origin = _originController.text.trim().toUpperCase();
    if (origin.isEmpty) {
      setState(() => _systemMessage = "ERROR: ORIGEN_VACÍO");
      return;
    }

    if (_vault.any((item) => item['origin'] == origin)) {
      setState(() => _systemMessage = "ERROR: CONFLICTO_DUPLICADO");
      return;
    }

    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#\$%^&*()';
    int length = isApexMode ? 32 : 12;
    String key = List.generate(length, (index) => chars[Random().nextInt(chars.length)]).join();
    String time = DateTime.now().toString().substring(11, 19);

    setState(() {
      _vault.insert(0, {'key': key, 'origin': origin, 'mode': isApexMode ? 'APEX' : 'BASE', 'time': time});
      _entropyLevel = min(1.0, _entropyLevel + (isApexMode ? 0.25 : 0.1));
      _systemMessage = "PROTOCOLO_${isApexMode ? 'APEX' : 'BASE'}_OK";
      _originController.clear();
    });
  }

  void _copyAndDestroy(String key) {
    Clipboard.setData(ClipboardData(text: key));
    setState(() => _systemMessage = "BUFFER: LIMPIEZA_AUTO_15S");
    
    Timer(const Duration(seconds: 15), () {
      Clipboard.setData(const ClipboardData(text: ""));
      if (mounted) setState(() => _systemMessage = "BUFFER: LIMPIO");
    });
  }

  @override
  Widget build(BuildContext context) {
    final akulColor = isApexMode ? Colors.red : const Color(0xFF00E5FF);

    if (!isAuthenticated) return _buildBiometric(akulColor);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          // INDICADOR DE ENTROPÍA (Más claro y grande)
          Padding(
            padding: const EdgeInsets.all(12),
            child: Stack(
              alignment: Alignment.center,
              children: [
                CircularProgressIndicator(
                  value: _entropyLevel,
                  strokeWidth: 3,
                  backgroundColor: Colors.white10,
                  color: akulColor,
                ),
                Text("${(_entropyLevel * 100).toInt()}%", style: TextStyle(color: akulColor, fontSize: 8)),
              ],
            ),
          ),
          IconButton(
            icon: Icon(Icons.bolt, color: akulColor, size: 20),
            onPressed: () => setState(() { _vault.clear(); _entropyLevel = 0.0; }),
          ),
          IconButton(
            icon: const Icon(Icons.power_settings_new, color: Colors.white24, size: 20),
            onPressed: () => setState(() => isAuthenticated = false),
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 25),
        child: Column(
          children: [
            const SizedBox(height: 20),
            // LOGO CENTRAL MINIMALISTA
            Text("AkulKeys", 
              style: TextStyle(color: akulColor, fontSize: 28, letterSpacing: 8, fontWeight: FontWeight.w200, fontFamily: 'monospace')),
            const SizedBox(height: 40),
            _buildTerminalHeader(akulColor),
            const SizedBox(height: 20),
            _buildInputSection(akulColor),
            const SizedBox(height: 30),
            Expanded(child: _buildVaultList(akulColor)),
          ],
        ),
      ),
    );
  }

  Widget _buildBiometric(Color color) {
    return Scaffold(
      body: GestureDetector(
        onTap: () => setState(() => isAuthenticated = true),
        child: Stack(
          children: [
            Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.fingerprint, size: 70, color: color.withOpacity(0.3)),
                  const SizedBox(height: 20),
                  Text("BIOMETRIC_SCAN_REQUIRED", style: TextStyle(color: color, letterSpacing: 5, fontSize: 9)),
                ],
              ),
            ),
            AnimatedBuilder(
              animation: _scanController,
              builder: (context, child) {
                return Positioned(
                  top: MediaQuery.of(context).size.height * 0.1 + (_scanController.value * MediaQuery.of(context).size.height * 0.8),
                  left: 0, right: 0,
                  child: Container(height: 1, decoration: BoxDecoration(color: color, boxShadow: [BoxShadow(color: color, blurRadius: 10)])),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTerminalHeader(Color color) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 15),
      decoration: BoxDecoration(border: Border(left: BorderSide(color: color, width: 2), bottom: BorderSide(color: color.withOpacity(0.1), width: 1))),
      child: Text(">> $_systemMessage", style: TextStyle(color: color, fontFamily: 'monospace', fontSize: 10)),
    );
  }

  Widget _buildInputSection(Color color) {
    return Column(
      children: [
        TextField(
          controller: _originController,
          style: const TextStyle(fontFamily: 'monospace', fontSize: 14),
          decoration: InputDecoration(
            hintText: "ID_OBJETIVO (EJ. AZURE_01)",
            hintStyle: const TextStyle(color: Colors.white10, fontSize: 10),
            border: InputBorder.none,
            prefixIcon: Icon(Icons.chevron_right, color: color, size: 16),
          ),
        ),
        const SizedBox(height: 10),
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                Text("APEX", style: TextStyle(color: isApexMode ? Colors.red : Colors.white10, fontSize: 9, letterSpacing: 2)),
                Switch(value: isApexMode, activeColor: Colors.red, onChanged: (v) => setState(() => isApexMode = v)),
              ],
            ),
            OutlinedButton(
              onPressed: _generateKey,
              style: OutlinedButton.styleFrom(side: BorderSide(color: color), shape: const ContinuousRectangleBorder()),
              child: Text("GEN_KEY", style: TextStyle(color: color, fontSize: 10, letterSpacing: 2)),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildVaultList(Color color) {
    return ListView.builder(
      itemCount: _vault.length,
      itemBuilder: (context, index) {
        final item = _vault[index];
        final bool isApex = item['mode'] == 'APEX';
        return Container(
          margin: const EdgeInsets.only(bottom: 10),
          decoration: BoxDecoration(color: Colors.white.withOpacity(0.01)),
          child: ListTile(
            onTap: () => _copyAndDestroy(item['key']!),
            dense: true,
            leading: Icon(Icons.terminal, color: isApex ? Colors.red : color, size: 14),
            title: Text(item['origin']!, style: const TextStyle(fontSize: 11, letterSpacing: 2)),
            subtitle: Text("NIVEL: ${item['mode']} | ${item['time']}", style: const TextStyle(color: Colors.white10, fontSize: 8)),
            trailing: const Icon(Icons.copy, color: Colors.white10, size: 12),
          ),
        );
      },
    );
  }
}